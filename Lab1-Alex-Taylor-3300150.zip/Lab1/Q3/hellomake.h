/*
Exmple include file
*/
#define SUCCESS 0
#define MYNUM 51

int myPrintHelloMake(void);