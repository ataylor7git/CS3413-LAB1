/*
Exmple include file
*/
int myPrintHelloMake(void);